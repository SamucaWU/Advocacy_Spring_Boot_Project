package github.io.advocacy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvocacyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvocacyApplication.class, args);
	}

}
